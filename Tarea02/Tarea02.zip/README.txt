Para crear los histogramas de las imagenes a buscar:
python tarea02.py setup
(La generacion de estos histogramas toma archivos de la carpeta dataset_1 en el formato provisto con los archivos anexados)

Para crear los histogramas de las imagenes de bosquejos:
python tarea02.py setup_sketches
(La generacion de estos histogramas toma archivos de la carpeta dataset_1 en el formato provisto con los archivos anexados)

Para realizar la comparación:
python tarea02.py compare
(La comparacion toma archivos de las carpetas HIST y SKETCH en el formato provisto con los archivos anexados)

Para ver una imagen con las orientaciones superpuestas:
python tarea02.py test_helo
o
python tarea02.py test_shelo